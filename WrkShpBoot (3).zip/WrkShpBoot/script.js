function showhidemenu() {
    let mn = document.querySelector('#nav-bar')
    if (mn.style.display === 'flex') {
        mn.style.display = 'none'
    } else {
        mn.style.display = 'flex'
    }
}

var x=0;
function fun()
{
x=x+1;
document.getElementById("demo").innerHTML = x;
}



// function checkPasswordMatch() {
   
// }
$(document).ready(function () {

    $('#txtConfirmPassword').keyup(function(){
 //  $("#clickPass").click(checkPasswordMatch);

 var password = $("#txtNewPassword").val();
    var confirmPassword = $("#txtConfirmPassword").val();
    if (password != confirmPassword)
        $("#msg").html("Password does not match!").css("color", "red");
    else 
        $("#msg").html("Password match. please submit").css("color", "green");
    


})
})




